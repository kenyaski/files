
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Initialization using the mandatory process.env.API_KEY
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface ChatMessagePart {
  text?: string;
  inlineData?: {
    data: string;
    mimeType: string;
  };
}

export interface ChatHistoryEntry {
  role: 'user' | 'model';
  parts: ChatMessagePart[];
}

export interface ChatParams {
  message: string;
  history: ChatHistoryEntry[];
  deepStudy?: boolean;
  contextFiles?: string[];
  image?: { data: string; mimeType: string };
}

/**
 * Generates an AI response grounded in institutional knowledge.
 * Adheres to NNP-GPT branding and academic constraints.
 */
export const generateAIResponse = async ({ 
  message, 
  history, 
  deepStudy = false, 
  contextFiles = [],
  image 
}: ChatParams): Promise<GenerateContentResponse> => {
  // Use recommended production models for Gemini 3 series
  const model = deepStudy ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview';
  
  const systemInstruction = `
    You are NNP-GPT, the official premium academic intelligence for Nyeri National Polytechnic.
    
    IDENTITY:
    - You are a specialized librarian and researcher.
    - Your tone is professional, encouraging, and strictly academic.
    
    INSTITUTIONAL GROUNDING:
    - You have priority access to these institutional assets: ${contextFiles.length > 0 ? contextFiles.join(', ') : 'General Polytechnic Curriculum'}.
    - ALWAYS prioritize answers from these specific documents.
    - Use Source Chips/Citations in your text as [Document Name] when quoting or summarizing.
    
    CONSTRAINTS:
    - STANDARD MODE: Max 150 words. Be direct and efficient.
    - DEEP STUDY MODE: Provide detailed, structured analysis with "Key Takeaways" and "Further Reading".
    - Avoid jargon unless it's specific to the student's department.
    - If the user asks for a quiz or summary, format it cleanly without unnecessary markdown characters.
  `;

  // Construct the contents array including history
  const contents: ChatHistoryEntry[] = [...history];
  
  // Add current user turn
  const currentParts: ChatMessagePart[] = [];
  if (image) {
    currentParts.push({
      inlineData: {
        data: image.data,
        mimeType: image.mimeType
      }
    });
  }
  currentParts.push({ text: message });
  
  contents.push({
    role: 'user',
    parts: currentParts
  });

  const config: any = {
    systemInstruction,
    temperature: 0.4,
  };

  if (deepStudy) {
    config.thinkingConfig = { thinkingBudget: 32768 };
  }

  try {
    const response = await ai.models.generateContent({
      model,
      contents: contents as any, // Cast to any to handle SDK type variations
      config: {
          ...config,
          tools: [{ googleSearch: {} }]
      }
    });

    if (!response || !response.text) {
      throw new Error("Empty response from AI node.");
    }

    return response;
  } catch (error) {
    console.error("AI Generation Failure:", error);
    throw error;
  }
};
