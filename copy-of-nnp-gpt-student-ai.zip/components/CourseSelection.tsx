
import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  Map, 
  Cpu, 
  Zap, 
  Briefcase, 
  Sprout, 
  ArrowRight,
  Users,
  UserCheck,
  ShieldCheck,
  ChevronDown,
  Lock,
  AlertCircle,
  User,
  Hash,
  Eye,
  EyeOff,
  GraduationCap,
  Settings
} from 'lucide-react';
import MasterLogo from './MasterLogo';
import { Course, UserRole } from '../types';
import { AVAILABLE_COURSES } from '../constants';

const ICON_MAP: Record<string, any> = {
  Map,
  Cpu,
  Zap,
  Briefcase,
  Sprout
};

const PASSWORDS = {
  lecturer: 'access@NNP.lec',
  admin: 'access@NNP.admin'
};

interface CourseSelectionProps {
  onSelect: (course: Course) => void;
  onAuthSuccess: (role: UserRole, preselectedCourse?: Course) => void;
  role: UserRole;
  setRole: (role: UserRole) => void;
  forceShowCourses?: boolean;
}

const CourseSelection: React.FC<CourseSelectionProps> = ({ 
  onSelect, 
  onAuthSuccess, 
  role, 
  setRole,
  forceShowCourses = false
}) => {
  const [search, setSearch] = useState('');
  const [pendingRole, setPendingRole] = useState<UserRole | null>(null);
  const [isVerifying, setIsVerifying] = useState(!forceShowCourses);
  
  // Security Inputs
  const [passwordInput, setPasswordInput] = useState('');
  const [studentName, setStudentName] = useState('');
  const [studentAdmission, setStudentAdmission] = useState('');
  const [studentCourseId, setStudentCourseId] = useState('');
  const [error, setError] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const filteredCourses = AVAILABLE_COURSES.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    c.department.toLowerCase().includes(search.toLowerCase())
  );

  const getRoleIcon = (r: UserRole) => {
    if (r === 'admin') return <ShieldCheck className="w-4 h-4" />;
    if (r === 'lecturer') return <Users className="w-4 h-4" />;
    return <UserCheck className="w-4 h-4" />;
  };

  const handleRoleClick = (newRole: UserRole) => {
    setPendingRole(newRole);
    setPasswordInput('');
    setStudentName('');
    setStudentAdmission('');
    setStudentCourseId('');
    setError(false);
    setShowPassword(false);
  };

  const verifyAccess = () => {
    if (!pendingRole) return;
    
    let success = false;
    let preselectedCourse: Course | undefined = undefined;

    if (pendingRole === 'student') {
      if (studentName.trim().length > 2 && studentAdmission.trim().length > 3 && studentCourseId) {
        success = true;
        preselectedCourse = AVAILABLE_COURSES.find(c => c.id === studentCourseId);
      }
    } else {
      const correctPassword = pendingRole === 'lecturer' ? PASSWORDS.lecturer : PASSWORDS.admin;
      if (passwordInput === correctPassword) {
        success = true;
      }
    }

    if (success) {
      setError(false);
      onAuthSuccess(pendingRole, preselectedCourse);
      setIsVerifying(false);
      setPendingRole(null);
    } else {
      setError(true);
    }
  };

  if (isVerifying) {
    return (
      <div className="min-h-screen bg-[#064e3b] dark:bg-[#022c22] flex flex-col items-center justify-center p-6 relative overflow-hidden transition-colors duration-300">
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-20">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-yellow-400 blur-[120px] rounded-full animate-pulse" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-emerald-300 blur-[120px] rounded-full" />
        </div>

        <div className="max-w-md w-full z-10 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <div className="text-center">
            <div className="inline-block hover:scale-105 transition-transform duration-500 mb-6 drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]">
              <MasterLogo size={180} />
            </div>
            <h1 className="text-white text-3xl font-black tracking-tight mb-2">Institutional Access</h1>
            <p className="text-emerald-100/60 text-sm font-medium uppercase tracking-widest">Verify identity to unlock academic AI</p>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-[40px] shadow-2xl p-8 space-y-6 border border-white/10 dark:border-white/5 transition-colors">
            {!pendingRole ? (
              <div className="space-y-3">
                {(['student', 'lecturer', 'admin'] as UserRole[]).map((r) => (
                  <button
                    key={r}
                    onClick={() => handleRoleClick(r)}
                    className="w-full flex items-center justify-between p-5 rounded-2xl border-2 border-slate-50 dark:border-slate-800 hover:border-[#064e3b] dark:hover:border-emerald-500 hover:bg-green-50 dark:hover:bg-emerald-900/10 transition-all group"
                  >
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-slate-50 dark:bg-slate-800 text-slate-400 dark:text-slate-500 group-hover:bg-[#064e3b] dark:group-hover:bg-emerald-600 group-hover:text-white rounded-xl transition-all">
                        {getRoleIcon(r)}
                      </div>
                      <span className="font-black text-slate-700 dark:text-slate-300 uppercase tracking-widest text-sm">{r} ACCESS</span>
                    </div>
                    <Lock className="w-4 h-4 text-slate-300 dark:text-slate-600 group-hover:text-[#064e3b] dark:group-hover:text-emerald-500 transition-colors" />
                  </button>
                ))}
              </div>
            ) : (
              <div className="space-y-6 animate-in fade-in zoom-in-95 duration-300">
                <div className="flex items-center justify-between">
                   <button onClick={() => setPendingRole(null)} className="text-slate-400 dark:text-slate-500 hover:text-[#064e3b] dark:hover:text-emerald-500 transition-colors">
                     <ArrowRight className="w-5 h-5 rotate-180" />
                   </button>
                   <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#064e3b] dark:text-emerald-500">{pendingRole} Verification</span>
                   <div className="w-5" />
                </div>

                <div className="space-y-4">
                  {pendingRole === 'student' ? (
                    <>
                      <div className="relative">
                        <User className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
                        <input 
                          type="text"
                          placeholder="Full Name"
                          autoFocus
                          value={studentName}
                          onChange={(e) => { setStudentName(e.target.value); setError(false); }}
                          className={`w-full pl-11 pr-4 py-4 bg-slate-50 dark:bg-slate-800 border-2 rounded-2xl text-sm text-slate-900 dark:text-slate-100 font-bold focus:outline-none transition-all ${error && !studentName ? 'border-red-200 dark:border-red-900/50 bg-red-50 dark:bg-red-900/10' : 'border-slate-50 dark:border-slate-700 focus:border-[#064e3b] dark:focus:border-emerald-500'}`}
                        />
                      </div>
                      <div className="relative">
                        <Hash className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
                        <input 
                          type="text"
                          placeholder="Admission Number"
                          value={studentAdmission}
                          onChange={(e) => { setStudentAdmission(e.target.value); setError(false); }}
                          className={`w-full pl-11 pr-4 py-4 bg-slate-50 dark:bg-slate-800 border-2 rounded-2xl text-sm text-slate-900 dark:text-slate-100 font-bold focus:outline-none transition-all ${error && !studentAdmission ? 'border-red-200 dark:border-red-900/50 bg-red-50 dark:bg-red-900/10' : 'border-slate-50 dark:border-slate-700 focus:border-[#064e3b] dark:focus:border-emerald-500'}`}
                        />
                      </div>
                      <div className="relative">
                        <GraduationCap className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
                        <select
                          value={studentCourseId}
                          onChange={(e) => { setStudentCourseId(e.target.value); setError(false); }}
                          className={`w-full pl-11 pr-4 py-4 bg-slate-50 dark:bg-slate-800 border-2 rounded-2xl text-sm text-slate-900 dark:text-slate-100 font-bold focus:outline-none appearance-none transition-all ${error && !studentCourseId ? 'border-red-200 dark:border-red-900/50 bg-red-50 dark:bg-red-900/10' : 'border-slate-50 dark:border-slate-700 focus:border-[#064e3b] dark:focus:border-emerald-500'}`}
                        >
                          <option value="" disabled className="dark:bg-slate-900">Select Registered Course</option>
                          {AVAILABLE_COURSES.length > 0 ? (
                            AVAILABLE_COURSES.map(course => (
                              <option key={course.id} value={course.id} className="dark:bg-slate-900">{course.name}</option>
                            ))
                          ) : (
                            <option value="" disabled>No Departments Configured</option>
                          )}
                        </select>
                        <ChevronDown className="w-4 h-4 absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500 pointer-events-none" />
                      </div>
                    </>
                  ) : (
                    <div className="relative">
                      <Lock className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
                      <input 
                        type={showPassword ? "text" : "password"}
                        placeholder="Institutional Passkey"
                        autoFocus
                        value={passwordInput}
                        onChange={(e) => { setPasswordInput(e.target.value); setError(false); }}
                        onKeyDown={(e) => e.key === 'Enter' && verifyAccess()}
                        className={`w-full pl-11 pr-12 py-4 bg-slate-50 dark:bg-slate-800 border-2 rounded-2xl text-sm text-slate-900 dark:text-slate-100 font-bold focus:outline-none transition-all ${error ? 'border-red-200 dark:border-red-900/50 bg-red-50 dark:bg-red-900/10' : 'border-slate-50 dark:border-slate-700 focus:border-[#064e3b] dark:focus:border-emerald-500'}`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-1/2 -translate-y-1/2 p-2 text-slate-300 dark:text-slate-600 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  )}

                  {error && (
                    <div className="flex items-center gap-2 text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/10 p-3 rounded-2xl border border-red-100 dark:border-red-900/20 animate-in shake">
                      <AlertCircle className="w-4 h-4" />
                      <span className="text-[10px] font-black uppercase">Missing or Invalid Credentials</span>
                    </div>
                  )}

                  <button 
                    onClick={verifyAccess}
                    className="w-full bg-[#064e3b] dark:bg-emerald-600 text-white py-4 rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-green-900/10 hover:scale-[1.02] active:scale-95 transition-all"
                  >
                    Unlock My Dashboard
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 text-center">
          <p className="text-white/40 text-[10px] font-black uppercase tracking-[0.3em] italic">
            powered by <span className="text-white/60">Elimu.GPT</span>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center p-6 sm:p-12 overflow-y-auto relative transition-colors duration-300">
      <div className="fixed top-0 left-0 w-full h-64 bg-[#064e3b] dark:bg-[#022c22] -z-10" />
      <div className="fixed top-32 left-1/2 -translate-x-1/2 w-[120%] h-[500px] bg-slate-50 dark:bg-slate-950 rounded-[100%] -z-10 shadow-2xl" />

      <div className="max-w-5xl w-full space-y-12 mb-20 animate-in fade-in slide-in-from-bottom-8 duration-700">
        <div className="text-center space-y-4 pt-8">
          <div className="inline-block hover:scale-105 transition-transform duration-500 mb-6 drop-shadow-2xl">
            <MasterLogo size={140} />
          </div>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-[#064e3b] dark:text-emerald-400 tracking-tight">Nyeri National Polytechnic</h2>
          <p className="text-slate-500 dark:text-slate-400 text-lg max-w-2xl mx-auto font-medium leading-relaxed uppercase tracking-widest text-xs">
            Personalized Academic Access Granted
          </p>
        </div>

        <div className="relative max-w-xl mx-auto">
          <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-slate-400 dark:text-slate-500" />
          </div>
          <input
            type="text"
            className="block w-full pl-12 pr-5 py-4 bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 rounded-3xl shadow-sm focus:ring-4 focus:ring-[#064e3b]/10 dark:focus:ring-emerald-500/10 focus:border-[#064e3b] dark:focus:border-emerald-500 transition-all text-slate-900 dark:text-slate-100 text-lg"
            placeholder="Search departments..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {filteredCourses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCourses.map((course, idx) => {
              const IconComponent = ICON_MAP[course.iconName] || BookOpen;
              return (
                <button
                  key={course.id}
                  onClick={() => onSelect(course)}
                  className="group relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 rounded-[40px] text-left transition-all hover:border-[#064e3b] dark:hover:border-emerald-500 hover:shadow-2xl hover:-translate-y-2 animate-in fade-in duration-500 fill-mode-both"
                  style={{ animationDelay: `${idx * 100}ms` }}
                >
                  <div className="flex flex-col h-full space-y-6">
                    <div className="flex items-center justify-between">
                      <div className="p-4 rounded-3xl bg-green-50 dark:bg-green-900/20 text-[#064e3b] dark:text-emerald-400 group-hover:bg-[#facc15] group-hover:text-[#064e3b] transition-all duration-300">
                        <IconComponent className="w-8 h-8" />
                      </div>
                      <span className="text-[11px] font-black uppercase tracking-[0.2em] text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 rounded-full">
                        {course.department}
                      </span>
                    </div>
                    <div className="space-y-3">
                      <h3 className="text-xl font-bold text-[#064e3b] dark:text-slate-100">{course.name}</h3>
                      <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed font-medium">{course.description}</p>
                    </div>
                    <div className="mt-auto pt-4 flex items-center gap-2 text-[#064e3b] dark:text-emerald-500 font-black text-sm opacity-0 group-hover:opacity-100 transition-all transform translate-x-4 group-hover:translate-x-0">
                      <span className="underline decoration-[#facc15] decoration-2 underline-offset-8">
                        {role === 'lecturer' ? 'Curate Archive' : 'Open Knowledge Base'}
                      </span>
                      <ArrowRight className="w-4 h-4 text-[#facc15]" />
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        ) : (
          <div className="py-24 text-center bg-white dark:bg-slate-900 rounded-[40px] border-2 border-dashed border-slate-200 dark:border-slate-800 animate-in fade-in duration-700">
             <Settings className="w-16 h-16 text-slate-300 dark:text-slate-700 mx-auto mb-6 animate-spin-slow" />
             <h3 className="text-xl font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Initial System Setup Required</h3>
             <p className="text-slate-400 dark:text-slate-600 text-sm mt-3 font-medium">Please login as Administrator to provision departments and curricula.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CourseSelection;
