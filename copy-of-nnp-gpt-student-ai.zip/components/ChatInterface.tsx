
import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Camera, 
  Mic, 
  Sparkles, 
  X,
  FileText,
  ShieldCheck,
  Search,
  BrainCircuit,
  Loader2
} from 'lucide-react';
import { Message, FileMetadata, UsageStats } from '../types';
import { generateAIResponse, ChatHistoryEntry } from '../services/geminiService';

interface ChatInterfaceProps {
  vault: FileMetadata[];
  selectedFile: FileMetadata | null;
  onFileDeselect: () => void;
  onUsageUpdate: (increment: number) => void;
  courseName: string;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
  vault,
  selectedFile, 
  onFileDeselect, 
  onUsageUpdate,
  courseName
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: `Welcome, Student. I am NNP-GPT. How can I assist your studies in ${courseName} today? I am currently synced with the Institutional Vault.`,
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [statusLine, setStatusLine] = useState<string | null>(null);
  const [deepStudyMode, setDeepStudyMode] = useState(false);
  const [pendingImage, setPendingImage] = useState<{ data: string; mimeType: string } | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, statusLine]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 128)}px`;
    }
  }, [input]);

  const handleSend = async () => {
    if ((!input.trim() && !pendingImage) || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      setStatusLine("Consulting Institutional Vault...");
      await new Promise(r => setTimeout(r, 600));
      setStatusLine(`Cross-referencing curriculum assets...`);

      // Prepare history for Gemini API
      const history: ChatHistoryEntry[] = messages
        .filter(m => m.id !== 'err') // Ignore error messages
        .map(m => ({
          role: m.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: m.content }]
        }));

      const contextFiles = vault.map(f => f.name);
      if (selectedFile && !contextFiles.includes(selectedFile.name)) {
        contextFiles.push(selectedFile.name);
      }

      const response = await generateAIResponse({
        message: input,
        history, 
        deepStudy: deepStudyMode,
        contextFiles: contextFiles,
        image: pendingImage || undefined
      });

      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.text || "I was unable to retrieve specific data for this query.",
        citations: selectedFile ? [selectedFile.name] : [],
        deepStudy: deepStudyMode,
      };

      setMessages(prev => [...prev, aiMsg]);
      onUsageUpdate(deepStudyMode ? 45 : 15); 
      setPendingImage(null);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { id: 'err', role: 'assistant', content: "Protocol error: Connection to knowledge node interrupted. Please check your credentials or retry." }]);
    } finally {
      setIsLoading(false);
      setStatusLine(null);
    }
  };

  const handleImageCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPendingImage({
          data: (reader.result as string).split(',')[1],
          mimeType: file.type
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const isInputEmpty = !input.trim() && !pendingImage;

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 transition-colors duration-300 relative">
      <div className="flex items-center justify-between px-4 py-2 border-b dark:border-slate-800 bg-slate-50 dark:bg-slate-950/40">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-[#064e3b] dark:text-emerald-500" />
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Institutional Grounding: ON</span>
          </div>
          <div className="h-3 w-px bg-slate-200 dark:bg-slate-800" />
          <div className="flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-blue-500" />
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">{vault.length} Assets Linked</span>
          </div>
        </div>
        {selectedFile && (
          <div className="flex items-center gap-2 bg-green-100 dark:bg-emerald-900/30 px-3 py-1 rounded-full animate-in fade-in zoom-in-95 duration-200">
             <Search className="w-3 h-3 text-[#064e3b] dark:text-emerald-400" />
             <span className="text-[9px] font-black text-[#064e3b] dark:text-emerald-400 truncate max-w-[120px]">INSPECTING: {selectedFile.name}</span>
             <button onClick={onFileDeselect} className="hover:text-red-500 transition-colors">
               <X className="w-2.5 h-2.5" />
             </button>
          </div>
        )}
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`
              max-w-[85%] lg:max-w-[70%] rounded-2xl p-4 shadow-sm animate-in zoom-in-95 duration-200
              ${msg.role === 'user' 
                ? 'bg-[#064e3b] dark:bg-emerald-700 text-white rounded-tr-none' 
                : 'bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-tl-none border border-slate-200 dark:border-slate-700'}
            `}>
              {msg.role === 'assistant' && msg.citations && msg.citations.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-3">
                  {msg.citations.map(c => (
                    <div key={c} className="flex items-center gap-1.5 bg-white dark:bg-slate-900 px-2 py-0.5 rounded-full text-[10px] font-bold text-[#064e3b] dark:text-emerald-400 border dark:border-slate-700 shadow-sm transition-colors">
                      <FileText className="w-3 h-3" />
                      {c}
                    </div>
                  ))}
                </div>
              )}
              
              <div className="text-sm leading-relaxed whitespace-pre-wrap">
                {msg.content}
              </div>

              {msg.deepStudy && (
                <div className="mt-4 pt-3 border-t border-slate-200/50 dark:border-slate-700 flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-[10px] font-bold text-[#064e3b] dark:text-emerald-400">
                    <BrainCircuit className="w-3.5 h-3.5" />
                    DEEP STUDY OUTPUT
                  </span>
                  <button className="text-[10px] underline font-bold text-green-600 dark:text-emerald-500">Download Notes</button>
                </div>
              )}
            </div>
          </div>
        ))}
        {statusLine && (
          <div className="flex justify-start">
            <div className="bg-green-50 dark:bg-emerald-900/10 border border-green-100 dark:border-emerald-900/20 rounded-full px-4 py-1.5 flex items-center gap-2">
              <Loader2 className="w-3 h-3 text-yellow-400 animate-spin" />
              <span className="text-[11px] font-medium text-green-700 dark:text-emerald-400 italic">{statusLine}</span>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t dark:border-slate-800 bg-white dark:bg-slate-900 sticky bottom-0 transition-colors">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-3 px-1">
             <button 
              onClick={() => setDeepStudyMode(!deepStudyMode)}
              className={`
                flex items-center gap-2 px-3 py-1.5 rounded-full text-[11px] font-bold transition-all
                ${deepStudyMode 
                  ? 'bg-yellow-100 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-400 border border-yellow-200 dark:border-yellow-700/50 shadow-sm' 
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'}
              `}
             >
               <Sparkles className={`w-3.5 h-3.5 ${deepStudyMode ? 'animate-pulse text-yellow-600 dark:text-yellow-400' : ''}`} />
               {deepStudyMode ? 'DEEP STUDY ACTIVE' : 'STANDARD MODE'}
             </button>
             {pendingImage && (
               <div className="flex items-center gap-2 bg-green-50 dark:bg-emerald-900/20 border border-green-100 dark:border-emerald-900/30 rounded-full px-3 py-1.5 text-[11px] font-bold text-green-700 dark:text-emerald-400">
                 <Camera className="w-3.5 h-3.5" />
                 PHOTO ATTACHED
                 <button onClick={() => setPendingImage(null)} className="hover:text-red-500 transition-colors">
                   <X className="w-3 h-3" />
                 </button>
               </div>
             )}
          </div>

          <div className="flex items-end gap-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-2 pr-3 focus-within:ring-2 focus-within:ring-[#064e3b]/5 dark:focus-within:ring-emerald-500/10 transition-all shadow-inner">
            <div className="flex flex-col gap-1 pl-2">
               <button 
                className="p-2 text-slate-400 dark:text-slate-500 hover:text-[#064e3b] dark:hover:text-emerald-400 transition-colors"
                onClick={() => fileInputRef.current?.click()}
               >
                 <Camera className="w-5 h-5" />
                 <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleImageCapture} />
               </button>
            </div>
            
            <textarea 
              ref={textareaRef}
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Ask about your course materials..."
              className="flex-1 bg-transparent border-none focus:ring-0 text-sm py-2 px-2 resize-none max-h-32 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 overflow-y-auto"
            />

            <div className="flex items-center gap-1.5">
              <button className="p-2 text-slate-400 dark:text-slate-500 hover:text-[#064e3b] dark:hover:text-emerald-400 transition-colors">
                <Mic className="w-5 h-5" />
              </button>
              <button 
                onClick={handleSend}
                disabled={isInputEmpty || isLoading}
                className={`
                  p-2.5 rounded-xl transition-all shadow-lg
                  ${!isInputEmpty && !isLoading 
                    ? 'bg-[#064e3b] dark:bg-emerald-600 text-white hover:scale-105 active:scale-95 shadow-green-900/20' 
                    : 'bg-slate-200 dark:bg-slate-700 text-slate-400 dark:text-slate-600 cursor-not-allowed opacity-60 shadow-none'}
                `}
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
          <p className="mt-2 text-[10px] text-center text-slate-400 dark:text-slate-500 font-medium uppercase tracking-tighter">
            Grounding enabled. Responses tailored to {courseName}.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
