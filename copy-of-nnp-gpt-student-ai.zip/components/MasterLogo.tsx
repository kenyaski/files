
import React from 'react';

interface MasterLogoProps {
  className?: string;
  size?: number;
}

const MasterLogo: React.FC<MasterLogoProps> = ({ className = "", size = 120 }) => {
  return (
    <div className={`relative inline-block ${className}`} style={{ width: size, height: size }}>
      <svg
        viewBox="0 0 1000 1000"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-2xl"
      >
        <defs>
          <linearGradient id="bgGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#0a2118" />
            <stop offset="100%" stopColor="#04120c" />
          </linearGradient>
          <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="15" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
          <filter id="softGlow" x="-10%" y="-10%" width="120%" height="120%">
            <feGaussianBlur stdDeviation="8" result="blur" />
          </filter>
        </defs>

        {/* Outer Silver Border Container */}
        <rect x="20" y="20" width="960" height="960" rx="180" fill="#71717a" />
        <rect x="35" y="35" width="930" height="930" rx="170" fill="url(#bgGradient)" />

        {/* Graduation Cap Icon */}
        <g filter="url(#neonGlow)">
          <path
            d="M500 240L180 390L500 540L820 390L500 240Z"
            stroke="#bbf7d0"
            strokeWidth="18"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M310 450V580C310 580 380 640 500 640C620 640 690 580 690 580V450"
            stroke="#bbf7d0"
            strokeWidth="18"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M335 460L335 320M335 460C335 460 325 480 335 500M335 460C335 460 345 480 335 500M315 540L335 500L355 540M305 560L335 500L365 560M335 500L335 580"
            stroke="#bbf7d0"
            strokeWidth="12"
            strokeLinecap="round"
          />
        </g>

        {/* Text Section */}
        <g filter="url(#softGlow)">
          <text
            x="500"
            y="760"
            textAnchor="middle"
            fill="white"
            style={{ fontSize: '240px', fontWeight: 900, fontFamily: 'Inter, sans-serif', letterSpacing: '-0.05em' }}
          >
            NNP
          </text>
          <text
            x="500"
            y="880"
            textAnchor="middle"
            fill="white"
            style={{ fontSize: '100px', fontWeight: 300, fontFamily: 'Inter, sans-serif', letterSpacing: '0.2em' }}
          >
            GPT
          </text>
        </g>
      </svg>
    </div>
  );
};

export default MasterLogo;
