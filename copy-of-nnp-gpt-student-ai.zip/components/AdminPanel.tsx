
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Users, 
  ShieldCheck, 
  Activity, 
  MoreVertical, 
  Search, 
  UserPlus, 
  Mail, 
  Filter,
  CheckCircle2,
  AlertCircle,
  UserCog,
  UserX,
  UserCheck,
  RefreshCw,
  X,
  History,
  Zap,
  Globe,
  TrendingUp,
  Cpu
} from 'lucide-react';
import { User, UserRole } from '../types';

// Cleared for deployment
const INITIAL_USERS: User[] = [];

// Generic logs for deployment
const LIVE_EVENTS = [
  "System initialized",
  "Uplink established",
  "Security grid active",
  "Node monitoring engaged"
];

const AdminPanel: React.FC = () => {
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [search, setSearch] = useState('');
  const [notification, setNotification] = useState<string | null>(null);
  const [tickerEvents, setTickerEvents] = useState<string[]>(LIVE_EVENTS);
  const [totalTokens, setTotalTokens] = useState(0);
  const [throughput, setThroughput] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      if (users.length > 0) {
        setTotalTokens(prev => prev + Math.floor(Math.random() * 150));
        setThroughput(prev => {
          const delta = (Math.random() - 0.5) * 2;
          return Math.max(5, Math.min(45, prev + delta));
        });
        if (Math.random() > 0.7) {
          const newEvent = LIVE_EVENTS[Math.floor(Math.random() * LIVE_EVENTS.length)];
          setTickerEvents(prev => [newEvent, ...prev.slice(0, 3)]);
        }
        setUsers(prev => prev.map(u => {
          if (Math.random() > 0.9 && u.status === 'active') {
            return { ...u, lastActive: 'Just now', recentActivity: 'Active in ' + (Math.random() > 0.5 ? 'Chat' : 'Library') };
          }
          return u;
        }));
      }
    }, 3000);
    return () => clearInterval(interval);
  }, [users.length]);

  const stats = useMemo(() => [
    { label: 'Campus Users', value: users.length.toString(), icon: Users, color: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-50 dark:bg-blue-900/20', trend: '+0%' },
    { label: 'Live Sessions', value: users.filter(u => u.status === 'active').length.toString(), icon: Activity, color: 'text-green-600 dark:text-emerald-400', bg: 'bg-green-50 dark:bg-emerald-900/20', trend: 'STABLE' },
    { label: 'Token Throughput', value: `${totalTokens.toLocaleString()}`, icon: Zap, color: 'text-yellow-600 dark:text-yellow-400', bg: 'bg-yellow-50 dark:bg-yellow-900/20', trend: `${throughput.toFixed(1)} t/s` },
  ], [users, totalTokens, throughput]);

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(search.toLowerCase()) || 
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const handleToggleStatus = (id: string) => {
    setUsers(prev => prev.map(u => {
      if (u.id === id) {
        const newStatus = u.status === 'active' ? 'inactive' : 'active';
        showNotification(`${u.name} status updated to ${newStatus}`);
        return { ...u, status: newStatus };
      }
      return u;
    }));
  };

  const handleEditRole = (id: string) => {
    const roles: UserRole[] = ['student', 'lecturer', 'admin'];
    setUsers(prev => prev.map(u => {
      if (u.id === id) {
        const currentIndex = roles.indexOf(u.role);
        const nextRole = roles[(currentIndex + 1) % roles.length];
        showNotification(`${u.name} role changed to ${nextRole}`);
        return { ...u, role: nextRole };
      }
      return u;
    }));
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-8 bg-slate-50 dark:bg-slate-950 relative transition-colors">
      <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-[#064e3b]/5 dark:bg-emerald-500/5 blur-[120px] rounded-full pointer-events-none" />

      {notification && (
        <div className="fixed top-20 right-8 z-[100] bg-[#064e3b] dark:bg-emerald-600 text-white px-6 py-4 rounded-2xl shadow-2xl border border-white/10 flex items-center gap-3 animate-in slide-in-from-right duration-300">
          <CheckCircle2 className="w-5 h-5 text-yellow-400" />
          <span className="text-sm font-black uppercase tracking-tight">{notification}</span>
          <button onClick={() => setNotification(null)} className="ml-4 opacity-50 hover:opacity-100">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      <div className="max-w-7xl mx-auto space-y-8">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="p-4 bg-[#064e3b] dark:bg-emerald-700 rounded-[24px] shadow-xl shadow-green-900/20">
              <Globe className="w-8 h-8 text-white animate-spin-slow" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-[#064e3b] dark:text-emerald-400 tracking-tighter uppercase italic">Oversight Command</h1>
              <p className="text-slate-500 dark:text-slate-400 font-bold text-xs uppercase tracking-[0.2em] flex items-center gap-2">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                Live Network Surveillance Active
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3 bg-white dark:bg-slate-900 p-2 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 transition-colors">
            <button className="flex items-center gap-2 bg-[#064e3b] dark:bg-emerald-600 text-white px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg hover:scale-[1.02] active:scale-95 transition-all">
              <UserPlus className="w-4 h-4 text-yellow-400" />
              Provision Access
            </button>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-6">
            {stats.map((stat) => (
              <div key={stat.label} className="bg-white dark:bg-slate-900 p-6 rounded-[32px] border border-slate-100 dark:border-slate-800 shadow-sm relative overflow-hidden group hover:border-[#064e3b]/20 dark:hover:border-emerald-500/20 transition-all">
                <div className="flex items-start justify-between">
                  <div className={`p-4 rounded-2xl ${stat.bg} ${stat.color}`}>
                    <stat.icon className={`w-8 h-8 ${stat.label === 'Live Sessions' ? 'animate-pulse' : ''}`} />
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 justify-end text-[10px] font-black text-green-600 dark:text-emerald-400 bg-green-50 dark:bg-emerald-900/10 px-2 py-0.5 rounded-full mb-1">
                      <TrendingUp className="w-3 h-3" />
                      {stat.trend}
                    </div>
                    <p className="text-xs font-black uppercase tracking-widest text-slate-400 dark:text-slate-500">{stat.label}</p>
                  </div>
                </div>
                <div className="mt-6 flex items-baseline gap-2">
                  <p className="text-3xl font-black text-slate-800 dark:text-slate-100 tracking-tighter tabular-nums transition-all duration-500">{stat.value}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-[#064e3b] dark:bg-[#022c22] p-6 rounded-[32px] text-white shadow-2xl flex flex-col justify-between overflow-hidden relative border border-white/10 transition-colors">
            <div className="relative z-10">
               <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-white/50 mb-4 flex items-center gap-2">
                 <Cpu className="w-3 h-3" /> System Logs
               </h3>
               <div className="space-y-3">
                 {tickerEvents.map((ev, i) => (
                   <div key={i} className="flex gap-3 animate-in slide-in-from-right duration-500" style={{ animationDelay: `${i * 150}ms` }}>
                     <div className="w-1 bg-yellow-400 rounded-full shrink-0 h-4 mt-1" />
                     <p className="text-[11px] font-bold text-white/80 line-clamp-1">{ev}</p>
                   </div>
                 ))}
               </div>
            </div>
            <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between relative z-10">
               <span className="text-[9px] font-black text-white/40 uppercase">Load: {throughput.toFixed(1)}%</span>
               <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="w-1 h-3 bg-yellow-400 rounded-full animate-bounce" style={{ animationDelay: `${i * 100}ms` }} />
                  ))}
               </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-8">
          <div className="bg-white dark:bg-slate-900 rounded-[40px] border border-slate-100 dark:border-slate-800 shadow-xl overflow-hidden transition-colors">
            <div className="p-8 border-b border-slate-50 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50/30 dark:bg-slate-800/20">
              <h2 className="text-xl font-black text-slate-800 dark:text-slate-100 flex items-center gap-3 italic">
                Active Node Directory
                <span className="bg-[#064e3b] dark:bg-emerald-600 text-white px-3 py-1 rounded-xl text-xs font-black">{users.length}</span>
              </h2>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
                  <input 
                    type="text" 
                    placeholder="Locate user/node..."
                    className="pl-9 pr-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm w-72 focus:ring-4 focus:ring-[#064e3b]/5 dark:focus:ring-emerald-500/5 focus:border-[#064e3b] dark:focus:border-emerald-500 transition-all text-slate-900 dark:text-slate-100"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-white dark:bg-slate-900 border-b border-slate-50 dark:border-slate-800">
                    <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 dark:text-slate-500">Identity Protocol</th>
                    <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 dark:text-slate-500">Class Type</th>
                    <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 dark:text-slate-500">Uptime Status</th>
                    <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 dark:text-slate-500">Live Telemetry</th>
                    <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 dark:text-slate-500">Command Overrides</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                  {filteredUsers.length > 0 ? filteredUsers.map((user) => (
                    <tr key={user.id} className="hover:bg-[#064e3b]/[0.02] dark:hover:bg-emerald-500/[0.05] transition-colors group">
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black text-[#064e3b] dark:text-emerald-400 border-2 border-white dark:border-slate-700 shadow-sm transition-all group-hover:bg-[#064e3b] dark:group-hover:bg-emerald-600 group-hover:text-white`}>
                            {user.name.charAt(0)}
                          </div>
                          <div>
                            <p className="text-sm font-black text-slate-800 dark:text-slate-100 tracking-tight">{user.name}</p>
                            <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider mt-0.5">
                              {user.email}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <span className={`text-[9px] font-black uppercase px-3 py-1.5 rounded-full border tracking-widest ${
                          user.role === 'admin' ? 'bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400 border-amber-100 dark:border-amber-900/50' :
                          user.role === 'lecturer' ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400 border-blue-100 dark:border-blue-900/50' :
                          'bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700'
                        }`}>
                          {user.role}
                        </span>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-3">
                          <div className={`w-2.5 h-2.5 rounded-full ${user.status === 'active' ? 'bg-green-500 animate-pulse' : 'bg-slate-300 dark:bg-slate-600'}`} />
                          <span className={`text-xs font-black uppercase tracking-tighter ${user.status === 'active' ? 'text-green-700 dark:text-emerald-500' : 'text-slate-400 dark:text-slate-600'}`}>
                            {user.status === 'active' ? 'ONLINE' : 'OFFLINE'}
                          </span>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex flex-col gap-1 max-w-[200px]">
                          <p className="text-[11px] text-slate-700 dark:text-slate-300 font-bold truncate flex items-center gap-1.5">
                            <History className="w-3.5 h-3.5 text-slate-400 dark:text-slate-600 group-hover:text-[#064e3b] dark:group-hover:text-emerald-400 transition-colors" />
                            {user.recentActivity}
                          </p>
                          <p className="text-[10px] font-black uppercase tracking-tighter text-slate-300 dark:text-slate-600">
                            PULSED: {user.lastActive}
                          </p>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => handleEditRole(user.id)}
                            className="p-3 bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-2xl hover:bg-blue-50 dark:hover:bg-blue-900/30 hover:text-blue-600 dark:hover:text-blue-400 transition-all"
                            title="Escalate Privilege"
                          >
                            <UserCog className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleToggleStatus(user.id)}
                            className={`p-3 rounded-2xl transition-all ${
                              user.status === 'active' 
                                ? 'bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 hover:bg-red-100' 
                                : 'bg-green-50 dark:bg-emerald-900/20 text-green-600 dark:text-emerald-400 hover:bg-green-100'
                            }`}
                            title={user.status === 'active' ? 'Terminate Session' : 'Grant Session'}
                          >
                            {user.status === 'active' ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                          </button>
                          <button className="p-3 text-slate-300 dark:text-slate-600 hover:text-slate-600 dark:hover:text-slate-300 rounded-2xl transition-all">
                            <MoreVertical className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  )) : (
                    <tr>
                      <td colSpan={5} className="px-8 py-24 text-center">
                        <div className="w-16 h-16 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-dashed border-slate-200 dark:border-slate-700">
                          <Users className="w-8 h-8 text-slate-300 dark:text-slate-600" />
                        </div>
                        <p className="text-slate-500 dark:text-slate-400 font-bold uppercase text-[10px] tracking-widest">No Active Nodes Provisioned</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="p-8 bg-slate-50/50 dark:bg-slate-800/20 flex items-center justify-between transition-colors">
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-600">Grid Scan: {filteredUsers.length} Nodes Resolved</p>
              <div className="flex items-center gap-2">
                <button disabled className="px-6 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-black text-slate-300 dark:text-slate-600 uppercase tracking-widest cursor-not-allowed">PREV</button>
                <button className="px-6 py-3 bg-[#064e3b] dark:bg-emerald-600 text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-md hover:scale-[1.02] transition-all">NEXT Grid</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <footer className="mt-12 py-8 text-center border-t border-slate-200 dark:border-slate-800 transition-colors">
         <p className="text-[9px] font-black uppercase tracking-[0.4em] text-slate-300 dark:text-slate-600 flex items-center justify-center gap-4">
           Institutional Security Grid V4.2 <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" /> Encrypted Polytechnic Uplink
         </p>
      </footer>
    </div>
  );
};

export default AdminPanel;
