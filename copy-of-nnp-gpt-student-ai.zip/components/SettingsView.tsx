
import React, { useState } from 'react';
import { 
  User, 
  Bell, 
  Shield, 
  Moon, 
  LogOut, 
  Smartphone, 
  Zap, 
  HelpCircle,
  ChevronRight,
  Sun,
  Trash2,
  Lock,
  RefreshCcw,
  CheckCircle2,
  ShieldAlert,
  Key,
  X,
  AlertTriangle
} from 'lucide-react';
import { UserRole } from '../types';

interface SettingsViewProps {
  userRole: UserRole;
  onRoleSwitch: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

const ADMIN_PASSKEY = 'access@NNP.admin';

const SettingsView: React.FC<SettingsViewProps> = ({ userRole, onRoleSwitch, isDarkMode, onToggleDarkMode }) => {
  const [showWipeSuccess, setShowWipeSuccess] = useState(false);
  const [isAuthorizingSwitch, setIsAuthorizingSwitch] = useState(false);
  const [adminKeyInput, setAdminKeyInput] = useState('');
  const [authError, setAuthError] = useState(false);

  const handleManualWipe = () => {
    localStorage.removeItem('chat_history_local');
    sessionStorage.clear();
    setShowWipeSuccess(true);
    setTimeout(() => {
      onRoleSwitch(); 
    }, 1500);
  };

  const handleAuthorizeSwitch = () => {
    if (adminKeyInput === ADMIN_PASSKEY) {
      setAuthError(false);
      onRoleSwitch();
    } else {
      setAuthError(true);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50 dark:bg-slate-950 p-6 transition-colors duration-300">
      <div className="max-w-2xl mx-auto space-y-6">
        <header className="mb-8">
          <h1 className="text-3xl font-black text-[#064e3b] dark:text-emerald-400 tracking-tight italic uppercase">Node Preferences</h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase tracking-widest flex items-center gap-2 mt-1">
            <Lock className="w-4 h-4" /> Academic Profile: Nyeri National Polytechnic
          </p>
        </header>

        {/* Account Profile */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 p-8 shadow-sm flex items-center gap-6 transition-colors">
          <div className="w-20 h-20 rounded-[2rem] bg-green-50 dark:bg-green-900/30 flex items-center justify-center border-4 border-white dark:border-slate-800 shadow-xl">
            <User className="w-10 h-10 text-[#064e3b] dark:text-emerald-400" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-black text-slate-800 dark:text-slate-100">NODE_{userRole.toUpperCase()}_ID_42081</h3>
            <p className="text-[#064e3b] dark:text-emerald-500 text-xs font-black uppercase tracking-[0.2em] mt-1">Verified Institutional Identity</p>
          </div>
          <div className="hidden sm:block">
            <div className="px-4 py-2 bg-slate-50 dark:bg-slate-800 rounded-2xl text-[10px] font-black text-slate-400 uppercase tracking-widest">Active Node</div>
          </div>
        </div>

        {/* Security & Role Migration Logic */}
        <div className="space-y-3">
          <h2 className="text-[10px] font-black uppercase tracking-[0.3em] text-red-500 dark:text-red-400 px-4 flex items-center gap-2">
            <ShieldAlert className="w-3.5 h-3.5" /> High-Level Authorization Required
          </h2>
          
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 overflow-hidden shadow-sm transition-colors">
            {!isAuthorizingSwitch ? (
              <button 
                onClick={() => setIsAuthorizingSwitch(true)}
                className="w-full flex items-center gap-5 p-6 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-left border-b border-slate-50 dark:border-slate-800 group"
              >
                <div className="p-3 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-2xl group-hover:scale-110 transition-transform">
                  <RefreshCcw className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-black text-slate-800 dark:text-slate-100 uppercase tracking-tight">Switch Faculty Identity</p>
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest mt-0.5">Role migration requires Admin passthrough</p>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-300 group-hover:translate-x-1 transition-transform" />
              </button>
            ) : (
              <div className="p-6 bg-red-50/30 dark:bg-red-900/5 animate-in slide-in-from-top-2 duration-300">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Key className="w-4 h-4 text-red-600 dark:text-red-400" />
                    <span className="text-xs font-black uppercase tracking-widest text-red-600 dark:text-red-400">Security Authorization Required</span>
                  </div>
                  <button onClick={() => { setIsAuthorizingSwitch(false); setAuthError(false); }} className="text-slate-400 hover:text-slate-600">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-4 font-medium uppercase tracking-tight">
                  Changing identity roles resets all local caches. Please provide the <strong>Admin Command Passkey</strong> to proceed with identity migration.
                </p>
                <div className="flex flex-col sm:flex-row gap-3">
                  <input 
                    type="password"
                    placeholder="Enter Admin Passkey..."
                    value={adminKeyInput}
                    onChange={(e) => { setAdminKeyInput(e.target.value); setAuthError(false); }}
                    className={`flex-1 px-4 py-3 bg-white dark:bg-slate-800 border-2 rounded-xl text-xs font-bold focus:outline-none transition-all ${authError ? 'border-red-500 ring-2 ring-red-500/10' : 'border-slate-100 dark:border-slate-700 focus:border-red-400'}`}
                    autoFocus
                  />
                  <button 
                    onClick={handleAuthorizeSwitch}
                    className="px-6 py-3 bg-red-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-700 transition-all shadow-lg shadow-red-900/10 active:scale-95"
                  >
                    Confirm Switch
                  </button>
                </div>
                {authError && (
                  <div className="mt-3 flex items-center gap-2 text-red-600 dark:text-red-400 text-[10px] font-black uppercase animate-in shake">
                    <AlertTriangle className="w-3.5 h-3.5" /> Invalid Admin Authorization
                  </div>
                )}
              </div>
            )}

            <button 
              onClick={handleManualWipe}
              className={`w-full flex items-center gap-5 p-6 transition-colors text-left border-b border-slate-50 dark:border-slate-800 group ${showWipeSuccess ? 'bg-green-50 dark:bg-emerald-900/20' : 'hover:bg-amber-50 dark:hover:bg-amber-900/10'}`}
            >
              <div className={`p-3 rounded-2xl transition-all ${showWipeSuccess ? 'bg-emerald-500 text-white' : 'bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-500 group-hover:scale-110'}`}>
                {showWipeSuccess ? <CheckCircle2 className="w-6 h-6" /> : <Trash2 className="w-6 h-6" />}
              </div>
              <div className="flex-1">
                <p className={`text-sm font-black uppercase tracking-tight ${showWipeSuccess ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-800 dark:text-slate-100'}`}>
                  {showWipeSuccess ? 'Session Wiped' : 'Wipe Local Node Data'}
                </p>
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest mt-0.5">Emergency purge of cached archives</p>
              </div>
            </button>
          </div>
        </div>

        {/* System Settings */}
        <div className="space-y-3">
          <h2 className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 dark:text-slate-600 px-4">Performance & Visuals</h2>
          
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 overflow-hidden shadow-sm transition-colors">
            <SettingItem icon={<Zap className="text-yellow-500" />} label="Deep Study Priority" sub="Gemini 1.5 Pro enabled" toggle />
            <SettingItem icon={<Smartphone className="text-blue-500" />} label="Outdoor High-Contrast" sub="Optimized for Nyeri sunlight" toggle defaultOn />
            <SettingItem 
              icon={isDarkMode ? <Sun className="text-yellow-400" /> : <Moon className="text-slate-400" />} 
              label="Night Protocol" 
              sub="OLED dark mode variant" 
              toggle 
              isOnOverride={isDarkMode}
              onToggleOverride={onToggleDarkMode}
            />
            <SettingItem icon={<Bell className="text-purple-500" />} label="Real-time Alerts" sub="Course update triggers" toggle defaultOn />
          </div>
        </div>

        <div className="pt-8 text-center pb-12">
           <p className="text-[9px] font-black uppercase tracking-[0.5em] text-slate-300 dark:text-slate-700">NNP-GPT Security Grid v4.2.1-PROD</p>
        </div>
      </div>
    </div>
  );
};

const SettingItem: React.FC<{ 
  icon: React.ReactNode; 
  label: string; 
  sub: string; 
  toggle?: boolean; 
  defaultOn?: boolean;
  isOnOverride?: boolean;
  onToggleOverride?: () => void;
}> = ({ icon, label, sub, toggle, defaultOn, isOnOverride, onToggleOverride }) => {
  const [internalOn, setInternalOn] = React.useState(defaultOn || false);
  
  const isOn = isOnOverride !== undefined ? isOnOverride : internalOn;
  const handleToggle = onToggleOverride || (() => setInternalOn(!internalOn));

  return (
    <div className="flex items-center gap-5 p-6 border-b border-slate-50 dark:border-slate-800 last:border-none transition-colors">
      <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl text-slate-500 dark:text-slate-400">
        {icon}
      </div>
      <div className="flex-1">
        <p className="text-sm font-black text-slate-800 dark:text-slate-100 uppercase tracking-tight">{label}</p>
        <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest mt-0.5">{sub}</p>
      </div>
      {toggle ? (
        <button 
          onClick={handleToggle}
          className={`w-12 h-7 rounded-full relative transition-all shadow-inner ${isOn ? 'bg-[#064e3b] dark:bg-emerald-600' : 'bg-slate-200 dark:bg-slate-700'}`}
        >
          <div className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform shadow-md ${isOn ? 'translate-x-5' : ''}`} />
        </button>
      ) : (
        <ChevronRight className="w-5 h-5 text-slate-300" />
      )}
    </div>
  );
};

export default SettingsView;
