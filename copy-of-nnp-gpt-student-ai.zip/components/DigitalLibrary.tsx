
import React, { useState } from 'react';
import { 
  Download, 
  Search, 
  FileText, 
  BookOpen, 
  Calendar, 
  Database,
  ExternalLink,
  CheckCircle,
  Tag as TagIcon,
  ShieldCheck,
  Lock,
  User,
  Clock,
  ChevronRight
} from 'lucide-react';
import { FileMetadata, Course } from '../types';

interface DigitalLibraryProps {
  course: Course | null;
  vault: FileMetadata[];
}

const DigitalLibrary: React.FC<DigitalLibraryProps> = ({ course, vault }) => {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const filteredVault = vault.filter(file => {
    const matchesSearch = file.name.toLowerCase().includes(search.toLowerCase()) || 
                          file.tags.some(t => t.toLowerCase().includes(search.toLowerCase()));
    const matchesCategory = !activeCategory || file.tags.includes(activeCategory);
    return matchesSearch && matchesCategory;
  });

  const allTags = Array.from(new Set(vault.flatMap(f => f.tags))).sort();

  const handleDownload = (file: FileMetadata) => {
    console.log(`Downloading: ${file.name}`);
    alert(`Institutional Access Granted: ${file.name} is being prepared for your local device.`);
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-50 dark:bg-slate-950 transition-colors overflow-hidden">
      {/* Dynamic Header Section */}
      <div className="bg-white dark:bg-slate-900 px-4 py-4 md:px-8 md:py-8 border-b border-slate-100 dark:border-slate-800 shadow-sm transition-colors z-20">
        <div className="max-w-6xl mx-auto space-y-4 md:space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3 md:gap-5">
              <div className="p-3 md:p-4 bg-[#064e3b] dark:bg-emerald-600 text-[#facc15] rounded-2xl md:rounded-[24px] shadow-xl shadow-green-900/10 shrink-0">
                <Database className="w-6 h-6 md:w-8 md:h-8" />
              </div>
              <div className="min-w-0">
                <h1 className="text-xl md:text-3xl font-black text-[#064e3b] dark:text-emerald-400 tracking-tighter uppercase italic leading-none truncate">Knowledge Archives</h1>
                <p className="text-slate-500 dark:text-slate-400 text-[10px] md:text-xs font-black uppercase tracking-[0.2em] mt-1 truncate">
                  Registered Node: {course?.name || 'Academic Core'}
                </p>
              </div>
            </div>
            <div className="hidden lg:flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-slate-800 px-5 py-2.5 rounded-full border border-slate-100 dark:border-slate-700 shadow-inner">
              <ShieldCheck className="w-4 h-4 text-green-500" />
              Institutional Integrity Grid v4.2
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-3 md:gap-4">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
              <input 
                type="text" 
                placeholder="Locate curriculum assets..."
                className="w-full pl-11 pr-4 py-3 md:py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl text-sm focus:ring-4 focus:ring-[#064e3b]/5 dark:focus:ring-emerald-500/5 transition-all text-slate-900 dark:text-slate-100 placeholder:text-slate-400 font-medium"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            
            {/* Scrollable Categories Container */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 -mx-4 px-4 md:mx-0 md:px-0 scrollbar-hide no-scrollbar touch-pan-x shrink-0">
              <button 
                onClick={() => setActiveCategory(null)}
                className={`px-4 py-3 md:px-6 md:py-4 rounded-xl md:rounded-2xl text-[10px] md:text-xs font-black uppercase tracking-widest whitespace-nowrap transition-all ${!activeCategory ? 'bg-[#facc15] text-[#064e3b] shadow-lg shadow-yellow-500/10' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'}`}
              >
                All Modules
              </button>
              {allTags.map(tag => (
                <button 
                  key={tag}
                  onClick={() => setActiveCategory(tag)}
                  className={`px-4 py-3 md:px-6 md:py-4 rounded-xl md:rounded-2xl text-[10px] md:text-xs font-black uppercase tracking-widest whitespace-nowrap transition-all flex items-center gap-2 ${activeCategory === tag ? 'bg-[#facc15] text-[#064e3b] shadow-lg shadow-yellow-500/10' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'}`}
                >
                  <TagIcon className="w-3.5 h-3.5" />
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Asset Grid - PC/Mobile Optimized Spacing */}
      <div className="flex-1 overflow-y-auto p-4 md:p-10 custom-scrollbar bg-slate-50/50 dark:bg-slate-950/50">
        <div className="max-w-7xl mx-auto">
          {filteredVault.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
              {filteredVault.map((file, idx) => (
                <div 
                  key={file.id} 
                  className="group relative bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[24px] md:rounded-[40px] p-5 md:p-8 shadow-sm hover:shadow-2xl hover:border-[#064e3b]/20 dark:hover:border-emerald-500/30 transition-all duration-500 animate-in fade-in slide-in-from-bottom-6"
                  style={{ animationDelay: `${idx * 40}ms` }}
                >
                  {/* Card Badge */}
                  <div className="absolute top-4 right-4 md:top-6 md:right-6">
                    <div className="flex items-center gap-1.5 px-3 py-1 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 text-[9px] font-black rounded-full border border-blue-100 dark:border-blue-900/50 uppercase tracking-tighter">
                      <Lock className="w-2.5 h-2.5" /> OFFICIAL
                    </div>
                  </div>

                  <div className="flex items-center gap-4 md:gap-6 mb-6">
                    <div className={`p-4 md:p-5 rounded-[20px] md:rounded-[28px] transition-all duration-500 group-hover:scale-110 group-hover:rotate-3 ${file.type === 'pdf' ? 'bg-red-50 dark:bg-red-900/20 text-red-600 shadow-red-900/5' : 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 shadow-emerald-900/5'}`}>
                      <FileText className="w-7 h-7 md:w-9 md:h-9" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="text-base md:text-xl font-black text-slate-800 dark:text-slate-100 line-clamp-2 leading-tight group-hover:text-[#064e3b] dark:group-hover:text-emerald-400 transition-colors">
                        {file.name}
                      </h3>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-[10px] font-black text-slate-400 dark:text-slate-600 uppercase tracking-widest flex items-center gap-1">
                          <Clock className="w-3 h-3" /> Term 2 Archival
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex flex-wrap gap-1.5 md:gap-2">
                      {file.tags.map(tag => (
                        <span key={tag} className="text-[9px] md:text-[10px] font-black bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 px-3 py-1 rounded-lg text-slate-500 dark:text-slate-400 group-hover:bg-green-50 dark:group-hover:bg-emerald-900/30 group-hover:text-green-600 dark:group-hover:text-emerald-400 transition-all flex items-center gap-1 uppercase tracking-tighter">
                          #{tag}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center gap-2 md:gap-4 pt-4 border-t border-slate-50 dark:border-slate-800">
                      <button 
                        onClick={() => handleDownload(file)}
                        className="flex-1 flex items-center justify-center gap-3 bg-[#064e3b] dark:bg-emerald-600 text-white py-3.5 md:py-5 rounded-[18px] md:rounded-[24px] text-[10px] md:text-xs font-black uppercase tracking-widest shadow-xl shadow-green-900/10 dark:shadow-emerald-900/30 hover:scale-[1.02] active:scale-95 transition-all"
                      >
                        <Download className="w-4 h-4 text-yellow-400" />
                        Download PDF
                      </button>
                      <button className="p-3.5 md:p-5 bg-slate-50 dark:bg-slate-800 text-slate-400 dark:text-slate-500 rounded-[18px] md:rounded-[24px] hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-600 dark:hover:text-slate-300 transition-all group/btn">
                        <ExternalLink className="w-4 h-4 group-hover/btn:rotate-12 transition-transform" />
                      </button>
                    </div>
                  </div>
                  
                  {/* Subtle PC-only hover detail */}
                  <div className="absolute bottom-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity hidden lg:block">
                     <p className="text-[8px] font-bold text-slate-300 uppercase tracking-widest">Verify ID to preview</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-24 md:py-40 text-center animate-in fade-in duration-700">
              <div className="w-24 h-24 md:w-32 md:h-32 bg-slate-100 dark:bg-slate-900 rounded-[40px] flex items-center justify-center mx-auto mb-8 border-4 border-dashed border-slate-200 dark:border-slate-800 group hover:border-[#064e3b] transition-colors">
                <BookOpen className="w-10 h-10 md:w-14 md:h-14 text-slate-300 dark:text-slate-700 group-hover:text-[#064e3b] transition-colors" />
              </div>
              <h3 className="text-xl md:text-2xl font-black text-slate-800 dark:text-slate-200 uppercase tracking-tighter italic">Archive Node Unresponsive</h3>
              <p className="text-slate-400 dark:text-slate-600 text-sm md:text-base mt-3 max-w-sm mx-auto font-medium leading-relaxed uppercase tracking-widest text-[10px]">
                No matching institutional assets resolved in this grid sector.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Footer Usage Bar - Condensed for Mobile */}
      <div className="p-4 md:p-6 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 transition-colors z-20">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          <p className="text-[9px] md:text-[11px] font-black uppercase tracking-[0.3em] text-slate-400 dark:text-slate-600 flex items-center justify-center gap-3">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
            Institutional Uplink Encrypted
          </p>
          <div className="hidden md:flex items-center gap-6">
            <div className="flex items-center gap-2 text-[10px] font-black text-slate-400">
              <User className="w-3.5 h-3.5" /> Student Node Active
            </div>
            <div className="w-px h-4 bg-slate-100 dark:bg-slate-800" />
            <p className="text-[10px] font-black text-[#064e3b] dark:text-emerald-500 uppercase italic">Polytechnic Registrar Verified</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DigitalLibrary;
