
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  Lock, 
  User, 
  Plus, 
  FileText, 
  Image as ImageIcon,
  File as FileIcon,
  Tag, 
  Search, 
  ChevronRight,
  UploadCloud,
  X,
  Zap,
  ShieldCheck,
  Flame,
  BookOpen
} from 'lucide-react';
import { FileMetadata, UsageStats, Course } from '../types';

interface SidebarProps {
  vault: FileMetadata[];
  research: FileMetadata[];
  usage: UsageStats;
  selectedCourse: Course | null;
  onSelect: (file: FileMetadata) => void;
  onUpload: (files: FileList | null) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ vault, research, usage, selectedCourse, onSelect, onUpload }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isPulsing, setIsPulsing] = useState(false);
  
  const prevUsedRef = useRef(usage.used);

  useEffect(() => {
    // Detect usage increase and trigger visual pulse/flicker effect
    if (usage.used > prevUsedRef.current) {
      setIsPulsing(true);
      const timer = setTimeout(() => setIsPulsing(false), 1200);
      prevUsedRef.current = usage.used;
      return () => clearTimeout(timer);
    }
    prevUsedRef.current = usage.used;
  }, [usage.used]);

  const percentage = Math.min((usage.used / usage.total) * 100, 100);

  // Extract all unique tags
  const allTags = useMemo(() => {
    const tags = new Set<string>();
    [...vault, ...research].forEach(file => {
      file.tags.forEach(tag => tags.add(tag));
    });
    return Array.from(tags).sort();
  }, [vault, research]);

  // Filtering logic
  const filterFiles = (files: FileMetadata[]) => {
    return files.filter(file => {
      const matchesSearch = file.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            file.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesTag = !selectedTag || file.tags.includes(selectedTag);
      return matchesSearch && matchesTag;
    });
  };

  const filteredVault = useMemo(() => filterFiles(vault), [vault, searchQuery, selectedTag]);
  const filteredResearch = useMemo(() => filterFiles(research), [research, searchQuery, selectedTag]);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onUpload(e.dataTransfer.files);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-hidden bg-white dark:bg-slate-900 transition-colors border-r dark:border-slate-800">
      {/* Course Context Header */}
      {selectedCourse && (
        <div className="p-4 bg-slate-50 dark:bg-slate-950/40 border-b dark:border-slate-800 animate-in fade-in duration-500">
          <div className="flex items-center gap-2 mb-1">
            <BookOpen className="w-3.5 h-3.5 text-[#064e3b] dark:text-emerald-400" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#064e3b] dark:text-emerald-400">Department Active</span>
          </div>
          <h2 className="text-sm font-black text-slate-800 dark:text-white truncate tracking-tight">{selectedCourse.name}</h2>
        </div>
      )}

      {/* Search & Filter Bar */}
      <div className="p-4 border-b dark:border-slate-800 space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search archives..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border-none rounded-lg text-sm focus:ring-2 focus:ring-[#064e3b]/10 dark:focus:ring-emerald-500/20 text-slate-900 dark:text-slate-100 transition-all placeholder:text-slate-400"
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>

        {/* Tag Filters */}
        {allTags.length > 0 && (
          <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide no-scrollbar">
            <button 
              onClick={() => setSelectedTag(null)}
              className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${!selectedTag ? 'bg-[#064e3b] text-white shadow-md' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-slate-200'}`}
            >
              All
            </button>
            {allTags.map(tag => (
              <button 
                key={tag}
                onClick={() => setSelectedTag(tag)}
                className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${selectedTag === tag ? 'bg-yellow-400 text-[#064e3b] shadow-md' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-slate-200'}`}
              >
                #{tag}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Files Sections */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-6">
        {/* Institutional Vault (Locked) */}
        <div>
          <div className="px-3 mb-2 flex items-center justify-between">
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 dark:text-slate-500 flex items-center gap-1.5">
              <ShieldCheck className="w-3 h-3" /> Institutional Vault
            </h3>
            <div className="px-1.5 py-0.5 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-[8px] font-black rounded uppercase border border-blue-100 dark:border-blue-900/50">
              Official
            </div>
          </div>
          <div className="space-y-1">
            {filteredVault.map(file => (
              <FileItem key={file.id} file={file} onClick={() => onSelect(file)} />
            ))}
            {filteredVault.length === 0 && (
              <p className="text-[10px] text-slate-400 dark:text-slate-600 px-3 italic">No matching official records.</p>
            )}
          </div>
        </div>

        {/* My Research (Private) */}
        <div 
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`rounded-2xl transition-all ${isDragging ? 'bg-green-50 dark:bg-emerald-900/20 ring-2 ring-dashed ring-green-400 p-2' : ''}`}
        >
          <div className="px-3 mb-2 flex items-center justify-between">
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 dark:text-slate-500 flex items-center gap-1.5">
              <User className="w-3 h-3" /> My Research
            </h3>
            <div className="px-1.5 py-0.5 bg-green-50 dark:bg-emerald-900/30 text-green-600 dark:text-emerald-400 text-[8px] font-black rounded uppercase border border-green-100 dark:border-emerald-900/50">
              Personal
            </div>
          </div>
          <div className="space-y-1">
            {filteredResearch.map(file => (
              <FileItem key={file.id} file={file} onClick={() => onSelect(file)} />
            ))}
            
            <label className="flex items-center gap-3 p-3 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-slate-400 hover:border-[#064e3b] dark:hover:border-emerald-500 hover:text-[#064e3b] dark:hover:text-emerald-500 transition-all cursor-pointer group mx-1">
              <UploadCloud className="w-4 h-4 group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-black uppercase tracking-widest">Drop research here</span>
              <input 
                type="file" 
                multiple 
                className="hidden" 
                onChange={(e) => onUpload(e.target.files)} 
              />
            </label>
          </div>
        </div>
      </div>

      {/* Usage Bar (Daily Allowance) */}
      <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t dark:border-slate-800 transition-colors">
        <div className="mb-2 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
             <Zap className={`w-3.5 h-3.5 transition-all ${isPulsing ? 'text-yellow-400 scale-125' : 'text-slate-400'}`} />
             <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 italic">Daily Allowance</span>
          </div>
          <span className={`text-[10px] font-black tabular-nums transition-colors ${isPulsing ? 'text-yellow-500' : 'text-slate-400'}`}>
            {usage.used}/{usage.total}
          </span>
        </div>
        <div className="h-2 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden relative shadow-inner">
          <div 
            className={`h-full bg-[#064e3b] dark:bg-emerald-600 rounded-full transition-all duration-700 relative ${isPulsing ? 'animate-pulse' : ''}`}
            style={{ width: `${percentage}%` }}
          >
            {isPulsing && (
               <div className="absolute inset-0 bg-white/40 animate-ping" />
            )}
            {percentage > 90 && (
               <div className="absolute top-0 right-0 h-full w-2 bg-red-400 animate-pulse" />
            )}
          </div>
        </div>
        {percentage > 75 && (
          <p className="mt-2 text-[8px] font-bold text-amber-600 dark:text-amber-500 uppercase tracking-tighter flex items-center gap-1">
            <Flame className="w-2.5 h-2.5" /> High throughput detected. Consider switching to Standard mode.
          </p>
        )}
      </div>
    </div>
  );
};

const FileItem: React.FC<{ file: FileMetadata; onClick: () => void }> = ({ file, onClick }) => {
  const getFileTypeIcon = () => {
    switch (file.type) {
      case 'pdf': return <FileText className="w-3 h-3" />;
      case 'image': return <ImageIcon className="w-3 h-3" />;
      case 'doc': return <FileIcon className="w-3 h-3" />;
      default: return <FileIcon className="w-3 h-3" />;
    }
  };

  return (
    <button 
      onClick={onClick}
      className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-all text-left group"
    >
      <div className={`p-2 rounded-lg shrink-0 transition-colors ${file.source === 'institutional' ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 group-hover:bg-blue-600 group-hover:text-white' : 'bg-green-50 dark:bg-emerald-900/20 text-green-600 dark:text-emerald-400 group-hover:bg-emerald-600 group-hover:text-white'}`}>
        {file.source === 'institutional' ? <Lock className="w-4 h-4" /> : <User className="w-4 h-4" />}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 min-w-0">
          <div className="shrink-0 text-slate-400 group-hover:text-current transition-colors">
            {getFileTypeIcon()}
          </div>
          <h4 className="text-xs font-bold text-slate-700 dark:text-slate-200 truncate group-hover:text-[#064e3b] dark:group-hover:text-emerald-400 transition-colors">
            {file.name}
          </h4>
        </div>
        <div className="flex flex-wrap gap-1 mt-1">
          {file.tags.map(tag => (
            <span key={tag} className="text-[8px] font-black uppercase tracking-tighter px-1.5 py-0.5 bg-slate-100 dark:bg-slate-900 text-slate-400 dark:text-slate-600 rounded group-hover:bg-white/50 dark:group-hover:bg-slate-800 transition-colors">
              #{tag}
            </span>
          ))}
        </div>
      </div>
      <ChevronRight className="w-3.5 h-3.5 text-slate-300 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
    </button>
  );
};

export default Sidebar;
