
import React from 'react';
import { MessageSquare, Library, Settings } from 'lucide-react';
import { Tab } from '../types';

interface BottomNavProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  return (
    <nav className="h-20 bg-white dark:bg-slate-900 border-t dark:border-slate-800 flex items-center justify-around px-4 pb-4 sticky bottom-0 z-50 transition-colors">
      <NavItem 
        icon={<MessageSquare className="w-6 h-6" />} 
        label="Chat" 
        isActive={activeTab === 'chat'} 
        onClick={() => setActiveTab('chat')} 
      />
      <NavItem 
        icon={<Library className="w-6 h-6" />} 
        label="Library" 
        isActive={activeTab === 'library'} 
        onClick={() => setActiveTab('library')} 
      />
      <NavItem 
        icon={<Settings className="w-6 h-6" />} 
        label="Settings" 
        isActive={activeTab === 'settings'} 
        onClick={() => setActiveTab('settings')} 
      />
    </nav>
  );
};

const NavItem: React.FC<{ 
  icon: React.ReactNode; 
  label: string; 
  isActive: boolean; 
  onClick: () => void 
}> = ({ icon, label, isActive, onClick }) => (
  <button 
    onClick={onClick}
    className={`
      flex flex-col items-center gap-1 p-2 rounded-xl transition-all
      ${isActive ? 'text-[#064e3b] dark:text-emerald-400 scale-110' : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300'}
    `}
  >
    <div className={`
      p-1.5 rounded-lg transition-colors
      ${isActive ? 'bg-yellow-50 dark:bg-yellow-900/10' : 'bg-transparent'}
    `}>
      {isActive ? React.cloneElement(icon as React.ReactElement<any>, { className: 'w-6 h-6 text-[#064e3b] dark:text-emerald-400' }) : icon}
    </div>
    <span className={`text-[10px] font-black uppercase tracking-widest ${isActive ? 'opacity-100' : 'opacity-60'}`}>
      {label}
    </span>
  </button>
);

export default BottomNav;
