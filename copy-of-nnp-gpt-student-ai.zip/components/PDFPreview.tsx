
import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Search, 
  X, 
  BrainCircuit, 
  Loader2, 
  ChevronDown, 
  ChevronUp, 
  ClipboardCheck, 
  CheckCircle2, 
  XCircle, 
  ArrowRight, 
  RotateCcw, 
  BookOpenCheck, 
  Zap,
  AlertCircle
} from 'lucide-react';
import { FileMetadata } from '../types';
import { generateAIResponse } from '../services/geminiService';

interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface PDFPreviewProps {
  file: FileMetadata | null;
  onManualClose?: () => void;
}

const PDFPreview: React.FC<PDFPreviewProps> = ({ file, onManualClose }) => {
  const [summary, setSummary] = useState<string | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [showFullSummary, setShowFullSummary] = useState(true);

  // Quiz State
  const [quizData, setQuizData] = useState<QuizQuestion[] | null>(null);
  const [isQuizGenerating, setIsQuizGenerating] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);

  const [previewSearch, setPreviewSearch] = useState('');

  const cleanText = (text: string) => {
    return text.replace(/\*\*|\*/g, '').replace(/#/g, '').trim();
  };

  const handleGenerateSummary = async () => {
    if (!file || isSummarizing) return;
    
    setIsSummarizing(true);
    setSummary(null);
    try {
      const prompt = `Generate a high-level academic executive summary of: "${file.content || 'the provided document'}". Focus on key concepts for a student. Remove all markdown bolding or hashes.`;
      
      const response = await generateAIResponse({
        message: prompt,
        history: [],
        deepStudy: false,
        contextFiles: [file.name]
      });

      setSummary(cleanText(response.text || "Summary unavailable."));
      setShowFullSummary(true);
    } catch (error) {
      setSummary("Error: Could not retrieve summary from knowledge node.");
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleGenerateQuiz = async () => {
    if (!file || isQuizGenerating) return;
    
    setIsQuizGenerating(true);
    setQuizData(null);
    setQuizFinished(false);
    setCurrentQuestionIndex(0);
    setScore(0);
    setIsAnswered(false);
    setSelectedOption(null);

    try {
      const prompt = `Based on: "${file.content || 'the provided document'}", create a 3-question interactive study quiz. 
      IMPORTANT: Return ONLY a valid raw JSON array. No markdown, no triple backticks.
      Structure: [{"question": "text", "options": ["A","B","C","D"], "correctAnswer": 0, "explanation": "text"}]`;
      
      const response = await generateAIResponse({
        message: prompt,
        history: [],
        deepStudy: false,
        contextFiles: [file.name]
      });

      const text = response.text || "[]";
      // Clean potential markdown code blocks returned by AI
      const jsonMatch = text.match(/\[.*\]/s);
      const cleanedJson = jsonMatch ? jsonMatch[0] : text;
      
      const parsedQuiz: QuizQuestion[] = JSON.parse(cleanedJson);
      
      // Secondary cleaning of strings within the JSON
      const fullyCleanedQuiz = parsedQuiz.map(q => ({
        ...q,
        question: cleanText(q.question),
        options: q.options.map(o => cleanText(o)),
        explanation: cleanText(q.explanation)
      }));

      setQuizData(fullyCleanedQuiz);
    } catch (error) {
      console.error("Quiz Parse Error:", error);
      alert("Assessment Generation Failed: Malformed data from intelligence node. Please retry.");
    } finally {
      setIsQuizGenerating(false);
    }
  };

  const handleOptionSelect = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
    setIsAnswered(true);
    if (quizData && index === quizData[currentQuestionIndex].correctAnswer) {
      setScore(prev => prev + 1);
    }
  };

  const handleNextQuestion = () => {
    if (!quizData) return;
    if (currentQuestionIndex < quizData.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setIsAnswered(false);
      setSelectedOption(null);
    } else {
      setQuizFinished(true);
    }
  };

  if (!file) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-slate-50 dark:bg-slate-950 transition-colors">
        <div className="w-20 h-20 bg-slate-100 dark:bg-slate-900 rounded-3xl flex items-center justify-center mb-6 border border-slate-200 dark:border-slate-800">
          <FileText className="w-10 h-10 text-slate-300 dark:text-slate-700" />
        </div>
        <h3 className="text-[#064e3b] dark:text-emerald-400 font-bold text-lg mb-2 uppercase tracking-tighter italic">Inspector Node</h3>
        <p className="text-slate-500 dark:text-slate-400 text-sm max-w-xs leading-relaxed font-medium">
          Awaiting document selection for deep academic inspection.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col h-full bg-white dark:bg-slate-900 transition-colors relative">
      {/* Header */}
      <div className="p-4 border-b dark:border-slate-800 flex items-center justify-between sticky top-0 bg-white dark:bg-slate-900 z-10 gap-3">
        <div className="flex items-center gap-3 overflow-hidden min-w-0">
          <div className="p-2 bg-green-50 dark:bg-emerald-900/20 text-[#064e3b] dark:text-emerald-400 rounded-lg flex-shrink-0">
            <FileText className="w-5 h-5" />
          </div>
          <div className="overflow-hidden">
            <h2 className="text-sm font-bold text-slate-800 dark:text-slate-100 truncate">{file.name}</h2>
            <p className="text-[10px] font-black text-green-600 dark:text-emerald-500 uppercase tracking-widest">Verified Vault Asset</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-slate-500 dark:text-slate-400">
            <Download className="w-4 h-4" />
          </button>
          {onManualClose && (
            <button onClick={onManualClose} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-slate-500 dark:text-slate-400">
                <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 custom-scrollbar bg-slate-50/30 dark:bg-slate-950/20">
        {/* Tool Bar */}
        <div className="flex items-center gap-2 mb-6">
          <button 
            onClick={handleGenerateSummary}
            disabled={isSummarizing}
            className="flex-1 flex items-center justify-center gap-2 bg-[#064e3b] dark:bg-emerald-600 text-white py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50"
          >
            {isSummarizing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <BrainCircuit className="w-3.5 h-3.5 text-yellow-400" />}
            {isSummarizing ? 'Analysing...' : 'Generate Summary'}
          </button>
          <button 
            onClick={handleGenerateQuiz}
            disabled={isQuizGenerating}
            className="flex-1 flex items-center justify-center gap-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[#064e3b] dark:text-emerald-400 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-50 transition-all disabled:opacity-50"
          >
            {isQuizGenerating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <BookOpenCheck className="w-3.5 h-3.5 text-emerald-500" />}
            {isQuizGenerating ? 'Generating...' : 'Self-Assessment'}
          </button>
        </div>

        {/* Summary Card */}
        {summary && (
          <div className="mb-6 bg-white dark:bg-slate-900 rounded-[28px] border border-[#064e3b]/10 dark:border-emerald-500/10 shadow-sm overflow-hidden animate-in fade-in duration-500">
            <div className="p-4 bg-[#064e3b]/5 dark:bg-emerald-500/5 flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-widest text-[#064e3b] dark:text-emerald-500 flex items-center gap-2">
                <Zap className="w-3 h-3 text-yellow-500" /> Key Insights
              </span>
              <button onClick={() => setShowFullSummary(!showFullSummary)} className="text-slate-400">
                {showFullSummary ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
            </div>
            {showFullSummary && (
              <div className="p-6 text-sm text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
                {summary}
              </div>
            )}
          </div>
        )}

        {/* Quiz View */}
        {quizData && (
          <div className="mb-8 bg-white dark:bg-slate-900 rounded-[32px] border border-emerald-500/10 shadow-xl overflow-hidden animate-in zoom-in-95">
             <div className="p-5 bg-[#064e3b] dark:bg-emerald-800 text-white flex items-center justify-between">
                <div>
                   <h3 className="text-xs font-black uppercase tracking-widest italic">Module Checkpoint</h3>
                   <p className="text-[10px] text-white/60 font-bold">Concept {currentQuestionIndex + 1} / {quizData.length}</p>
                </div>
                <div className="px-3 py-1 bg-white/10 rounded-full text-[10px] font-black">
                   SCORE: {score}
                </div>
             </div>

             <div className="p-6">
                {!quizFinished ? (
                  <div className="space-y-6">
                    <h4 className="text-base font-bold text-slate-800 dark:text-white leading-tight">
                      {quizData[currentQuestionIndex].question}
                    </h4>
                    <div className="space-y-2">
                      {quizData[currentQuestionIndex].options.map((option, idx) => {
                        const isCorrect = idx === quizData[currentQuestionIndex].correctAnswer;
                        const isSelected = selectedOption === idx;
                        let stateStyles = "border-slate-100 dark:border-slate-800 hover:border-[#064e3b] dark:hover:border-emerald-500";
                        if (isAnswered) {
                          if (isCorrect) stateStyles = "bg-green-50 dark:bg-emerald-900/20 border-green-500";
                          else if (isSelected) stateStyles = "bg-red-50 dark:bg-red-900/20 border-red-500";
                          else stateStyles = "opacity-40 border-slate-100 dark:border-slate-800";
                        }
                        return (
                          <button
                            key={idx}
                            disabled={isAnswered}
                            onClick={() => handleOptionSelect(idx)}
                            className={`w-full text-left p-4 rounded-2xl border-2 transition-all text-xs font-bold ${stateStyles}`}
                          >
                            {option}
                          </button>
                        );
                      })}
                    </div>
                    {isAnswered && (
                      <div className="mt-4 p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl animate-in slide-in-from-top-2">
                        <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Feedback</p>
                        <p className="text-xs text-slate-600 dark:text-slate-400 font-medium italic">
                          {quizData[currentQuestionIndex].explanation}
                        </p>
                        <button 
                          onClick={handleNextQuestion}
                          className="mt-4 w-full bg-[#064e3b] dark:bg-emerald-600 text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-widest"
                        >
                          {currentQuestionIndex < quizData.length - 1 ? 'Next' : 'Finish'}
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-6">
                     <div className="w-20 h-20 rounded-full bg-green-50 dark:bg-emerald-900/30 flex items-center justify-center mx-auto mb-4 border-2 border-emerald-500">
                        <span className="text-2xl font-black text-[#064e3b] dark:text-emerald-400">{score}/{quizData.length}</span>
                     </div>
                     <h4 className="font-black text-slate-800 dark:text-white uppercase tracking-tighter">Assessment Complete</h4>
                     <button onClick={() => setQuizData(null)} className="mt-6 px-8 py-3 bg-[#064e3b] dark:bg-emerald-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest">Done</button>
                  </div>
                )}
             </div>
          </div>
        )}

        {/* Paper Simulation */}
        <div className="bg-white dark:bg-slate-900 p-8 rounded-[32px] border border-slate-200 dark:border-slate-800 shadow-sm min-h-[500px] transition-colors">
          <div className="flex items-center justify-between mb-8 pb-4 border-b dark:border-slate-800">
             <div className="flex items-center gap-2 text-[10px] font-black text-slate-300 dark:text-slate-600 uppercase tracking-widest">
                <FileText className="w-3.5 h-3.5" /> Institutional Asset Grid
             </div>
             <span className="text-[9px] font-black text-slate-200 dark:text-slate-700 tracking-widest">PG 1 // 12</span>
          </div>
          <div className="space-y-6">
             <div className="h-4 bg-slate-50 dark:bg-slate-800/50 rounded-full w-3/4" />
             <div className="h-4 bg-slate-50 dark:bg-slate-800/50 rounded-full w-full" />
             <div className="h-4 bg-slate-50 dark:bg-slate-800/50 rounded-full w-5/6" />
             <div className="py-8 border-y border-slate-50 dark:border-slate-800 my-8">
                <p className="text-sm text-slate-400 dark:text-slate-600 font-medium italic leading-relaxed">
                  "{file.content || 'Content analysis in progress. Select deep inspection for higher granularity.'}"
                </p>
             </div>
             <div className="h-4 bg-slate-50 dark:bg-slate-800/50 rounded-full w-full" />
             <div className="h-4 bg-slate-50 dark:bg-slate-800/50 rounded-full w-2/3" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PDFPreview;
