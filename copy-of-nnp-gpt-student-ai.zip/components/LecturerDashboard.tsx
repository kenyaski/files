import React, { useState } from 'react';
// Fixing missing icon import for ShieldCheck used in the grounding card
import { 
  UploadCloud, 
  FileText, 
  Trash2, 
  RefreshCw, 
  Search, 
  Image as ImageIcon, 
  Plus, 
  MoreVertical,
  CheckCircle,
  Clock,
  ExternalLink,
  Edit3,
  Save,
  X,
  BookOpen,
  ArrowLeft,
  Loader2,
  ShieldCheck
} from 'lucide-react';
import { FileMetadata, Course } from '../types';

interface LecturerDashboardProps {
  course: Course;
  vault: FileMetadata[];
  onUpload: (files: FileList | null) => void;
  onDelete: (id: string) => void;
  onUpdate: (id: string, updates: Partial<FileMetadata>) => void;
  onBack: () => void;
}

const LecturerDashboard: React.FC<LecturerDashboardProps> = ({ 
  course, 
  vault, 
  onUpload, 
  onDelete, 
  onUpdate,
  onBack 
}) => {
  const [search, setSearch] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  const filteredVault = vault.filter(f => 
    f.name.toLowerCase().includes(search.toLowerCase()) ||
    f.tags.some(t => t.toLowerCase().includes(search.toLowerCase()))
  );

  const handleSync = () => {
    setIsSyncing(true);
    setTimeout(() => setIsSyncing(false), 2000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    setIsUploading(true);
    
    // Simulate server processing/indexing time
    setTimeout(() => {
      onUpload(e.target.files);
      setIsUploading(false);
    }, 1200);
  };

  const startEditing = (file: FileMetadata) => {
    setEditingId(file.id);
    setEditName(file.name);
  };

  const saveEdit = (id: string) => {
    onUpdate(id, { name: editName });
    setEditingId(null);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-8 bg-slate-50 dark:bg-slate-950 transition-colors">
      <div className="max-w-6xl mx-auto space-y-8">
        <nav className="flex items-center justify-between mb-4">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-slate-500 dark:text-slate-400 hover:text-[#064e3b] dark:hover:text-emerald-400 font-bold text-sm transition-colors group"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            Back to Course Selection
          </button>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-green-100 dark:bg-emerald-900/20 text-[#064e3b] dark:text-emerald-400 rounded-full text-[10px] font-black uppercase tracking-widest border border-green-200 dark:border-emerald-900/50">
              Vault Curator Mode
            </span>
          </div>
        </nav>

        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white dark:bg-slate-900 p-8 rounded-[40px] border border-slate-100 dark:border-slate-800 shadow-sm transition-colors">
          <div className="flex items-center gap-5">
            <div className="p-5 rounded-3xl bg-[#064e3b] dark:bg-emerald-700 text-[#facc15] shadow-xl shadow-green-900/10">
              <BookOpen className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-[#064e3b] dark:text-emerald-400 tracking-tight">{course.name}</h1>
              <p className="text-slate-500 dark:text-slate-400 font-medium">Institutional Knowledge Curator</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-3">
             <button 
              onClick={handleSync}
              className="flex items-center gap-2 px-5 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:border-green-500 transition-all shadow-sm"
             >
               <RefreshCw className={`w-4 h-4 text-green-600 dark:text-emerald-500 ${isSyncing ? 'animate-spin' : ''}`} />
               {isSyncing ? 'Indexing...' : 'Sync All Assets'}
             </button>
             <label className={`flex items-center gap-2 px-6 py-3 bg-[#064e3b] dark:bg-emerald-600 text-white rounded-2xl text-xs font-black shadow-lg shadow-green-900/20 hover:scale-[1.02] active:scale-95 cursor-pointer transition-all ${isUploading ? 'opacity-70 pointer-events-none' : ''}`}>
               {isUploading ? <Loader2 className="w-4 h-4 animate-spin text-yellow-400" /> : <Plus className="w-4 h-4 text-yellow-400" />}
               {isUploading ? 'Uploading Assets...' : 'New Vault Asset'}
               <input 
                type="file" 
                multiple 
                accept=".pdf,image/*" 
                className="hidden" 
                onChange={handleFileUpload} 
               />
             </label>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-[40px] border border-slate-100 dark:border-slate-800 shadow-xl overflow-hidden transition-colors">
              <div className="p-8 border-b border-slate-50 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <h2 className="text-xl font-bold text-slate-800 dark:text-white">Active Repository</h2>
                  <span className="bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 px-3 py-1 rounded-full text-xs font-black">
                    {filteredVault.length} Linked
                  </span>
                </div>
                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
                  <input 
                    type="text" 
                    placeholder="Search curriculum..."
                    className="w-full pl-9 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800 border-none rounded-xl text-sm focus:ring-2 focus:ring-green-500/20 text-slate-900 dark:text-slate-100"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
              </div>

              <div className="divide-y divide-slate-50 dark:divide-slate-800">
                {filteredVault.length > 0 ? filteredVault.map((file) => (
                  <div key={file.id} className="p-6 hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors flex items-center justify-between group">
                    <div className="flex items-center gap-5 flex-1 min-w-0">
                      <div className={`p-4 rounded-2xl shrink-0 ${file.type === 'pdf' ? 'bg-green-50 dark:bg-emerald-900/20 text-green-700 dark:text-emerald-400' : 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400'}`}>
                        {file.type === 'pdf' ? <FileText className="w-6 h-6" /> : <ImageIcon className="w-6 h-6" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        {editingId === file.id ? (
                          <div className="flex items-center gap-2">
                            <input 
                              type="text"
                              value={editName}
                              onChange={(e) => setEditName(e.target.value)}
                              className="bg-white dark:bg-slate-800 border-2 border-green-500 dark:border-emerald-600 rounded-lg px-2 py-1 text-sm font-bold w-full focus:outline-none text-slate-900 dark:text-white"
                              autoFocus
                            />
                            <button onClick={() => saveEdit(file.id)} className="p-1.5 text-green-600 dark:text-emerald-500 hover:bg-green-100 dark:hover:bg-emerald-900/30 rounded-lg">
                              <Save className="w-4 h-4" />
                            </button>
                            <button onClick={() => setEditingId(null)} className="p-1.5 text-slate-400 dark:text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg">
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ) : (
                          <h4 className="font-bold text-slate-800 dark:text-white truncate">{file.name}</h4>
                        )}
                        <div className="flex items-center gap-3 mt-1.5">
                          <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full">
                            {file.type}
                          </span>
                          <span className="text-[10px] text-slate-400 dark:text-slate-500 flex items-center gap-1.5 font-medium">
                            <CheckCircle className="w-3 h-3 text-green-500" />
                            AI Grounding Reference
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => startEditing(file)}
                        className="p-2.5 text-slate-400 dark:text-slate-500 hover:text-[#064e3b] dark:hover:text-emerald-400 hover:bg-white dark:hover:bg-slate-800 rounded-xl transition-all"
                        title="Edit Metadata"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => onDelete(file.id)}
                        className="p-2.5 text-slate-400 dark:text-slate-500 hover:text-red-500 hover:bg-white dark:hover:bg-slate-800 rounded-xl transition-all"
                        title="Remove Reference"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )) : (
                  <div className="p-24 text-center">
                    <p className="text-slate-400 dark:text-slate-500 font-bold uppercase text-[10px] tracking-widest">No assets provisioned for AI training</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-[#064e3b] dark:bg-[#022c22] text-white p-8 rounded-[40px] shadow-2xl relative overflow-hidden transition-colors">
              <div className="relative z-10">
                <div className="inline-flex p-3 rounded-2xl bg-white/10 mb-6">
                  <ShieldCheck className="w-6 h-6 text-[#facc15]" />
                </div>
                <h3 className="text-xl font-bold mb-2">Institutional Grounding</h3>
                <p className="text-green-100/70 text-sm leading-relaxed mb-6 font-medium">
                  Assets uploaded here are automatically indexed. Gemini uses these to ground student answers in official curriculum.
                </p>
                <div className="space-y-4">
                  <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                    <div className={`h-full bg-[#facc15] shadow-[0_0_10px_rgba(250,204,21,0.5)] transition-all duration-1000 ${isSyncing ? 'w-full' : 'w-4/5'}`} />
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-8 rounded-[40px] border border-slate-100 dark:border-slate-800 shadow-xl transition-colors">
               <h3 className="text-sm font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-6">Real-time Telemetry</h3>
               <div className="space-y-6">
                 {isUploading && (
                   <div className="flex items-center gap-3 animate-in fade-in slide-in-from-right duration-300">
                     <Loader2 className="w-4 h-4 text-[#064e3b] dark:text-emerald-500 animate-spin" />
                     <p className="text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-tight">Processing curriculum stream...</p>
                   </div>
                 )}
                 <p className="text-[10px] font-bold text-slate-400 dark:text-slate-600 uppercase tracking-tighter">
                   System listening for administrative updates...
                 </p>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LecturerDashboard;